#include <iostream>
#include <string>
#include <vector>
#include <array>

using namespace std;

//customer-9
void CustomerInfo();
void customerOperation();
void AddCustomer();
void DeleteCustomer();
void EditCustomer();
void ShowCustomer();

int compareCustomerId(int id); 
int compareCustomerPhone(int phone); 
int compareCustomerTablenum(int table); 

void HomeScreen();

// CLASS CUSTOMER
class Customer{
	
	public:
		int customerId;
		string customerName;
		int customerPhone;
		string customerAddress;
		int customerTablenum;
			
	Customer(int, string, int, string, int);
			
	void CustomerInfo() {
		cout << "Customer Id: "<<customerId<< endl;
		cout << "	 Name: "<<customerName<< endl;
		cout << "   	 Phone: "<<customerPhone<< endl;
		cout << "	 Address: "<<customerAddress<< endl;
		cout << "	 Table Number: "<<customerTablenum<< endl;
		cout<<"\n";
	}
							
};

vector<Customer>Customers;

Customer::Customer(int customerId, string customerName, int customerPhone, string customerAddress, int customerTablenum){
	
	this->customerId=customerId;
	this->customerName=customerName;     
	this->customerPhone=customerPhone;
	this->customerAddress=customerAddress;
	this->customerTablenum=customerTablenum;
	
	Customers.push_back(*this);
}

