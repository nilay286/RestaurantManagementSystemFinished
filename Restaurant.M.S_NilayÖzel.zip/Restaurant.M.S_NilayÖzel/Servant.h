#include <iostream>
#include <string>
#include <vector>
#include <array>

using namespace std;

//servant-10
void ServantInfo();
void servantOperation();
void AddServant();
void DeleteServant();
void EditServant();
void ShowServant();

int compareServantId(int id); 
int compareServantPhone(int phone); 
int compareServantTable(int table);
int compareServantAge(int age); 

void HomeScreen();

//CLASS SERVANT
class Servant{
	
	public:
		
		int servantId;
		string servantName;
		int servantAge;
		int servantPhone;
		int servantTable;

	Servant(int, string, int, int, int);	
		
	void ServantInfo() {
		cout << "Servant Id: "<<servantId<<endl;
		cout << "       Name: "<<servantName<<endl;
		cout << "       Age: "<<servantAge<<endl;
		cout << "       Phone: "<<servantPhone<<endl;
		cout << "       Table you are responsible for: "<<servantTable<<endl;
		cout<<"\n";
	}
};

vector<Servant>Servants;

Servant::Servant(int servantId, string servantName, int servantAge, int servantPhone, int servantTable){
	
	this->servantId=servantId;
	this->servantName=servantName;
	this->servantAge=servantAge;
	this->servantPhone=servantPhone;
	this->servantTable=servantTable;
	
	Servants.push_back(*this);
}

