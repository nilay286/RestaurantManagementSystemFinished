#include <iostream>
#include <string>
#include <vector>
#include <array>

using namespace std;

//chef-9
void ChefInfo();
void chefOperation();
void AddChef();
void DeleteChef();
void EditChef();
void ShowChef();

int compareChefId(int id);
int compareChefPhone(int phone); 
int compareChefAge(int age);  

void HomeScreen();

//CLASS CHEF
class Chef{
	
	public:
		
		int chefId;
		string chefName;
		int chefAge;
		int chefPhone;	
	
	Chef(int, string, int, int);	
	
	void ChefInfo() {
		cout << "Chef Id: "<<chefId<< endl;
		cout << "     Name: "<<chefName<< endl;
		cout << "     Age: "<<chefAge<<endl;
		cout << "     Phone: "<<chefPhone<< endl;
		cout<<"\n";
	}		
};

vector<Chef>Chefs;

Chef::Chef(int chefId, string chefName, int chefAge, int chefPhone){
	
	this->chefId=chefId;
	this->chefName=chefName;
	this->chefAge=chefAge;
	this->chefPhone=chefPhone;
	
	Chefs.push_back(*this);
}

