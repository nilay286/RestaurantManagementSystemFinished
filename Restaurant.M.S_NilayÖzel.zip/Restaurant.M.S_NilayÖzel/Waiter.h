#include <iostream>
#include <string>
#include <vector>
#include <array>

using namespace std;

//waiter-10
void WaiterInfo();
void waiterOperation();
void AddWaiter();
void DeleteWaiter();
void EditWaiter();
void ShowWaiter();

int compareWaiterId(int id); 
int compareWaiterPhone(int phone); 
int compareWaiterTable(int table);
int compareWaiterAge(int age); 

void HomeScreen();

//CLASS WAITER
class Waiter{
	
	public:	
		int waiterId;
		string waiterName;
		int waiterAge;
		int waiterPhone;
		int waiterTable;

	Waiter(int, string, int, int, int);	
		
	void WaiterInfo() {
		cout << "Waiter Id: "<<waiterId<<endl;
		cout << "       Name: "<<waiterName<<endl;
		cout << "       Age: "<<waiterAge<<endl;
		cout << "       Phone: "<<waiterPhone<<endl;
		cout << "       Table you are responsible for: "<<waiterTable<<endl;
		cout<<"\n";
	}
};

vector<Waiter>Waiters;

Waiter::Waiter(int waiterId, string waiterName, int waiterAge, int waiterPhone, int waiterTable){
	
	this->waiterId=waiterId;
	this->waiterName=waiterName;
	this->waiterAge=waiterAge;
	this->waiterPhone=waiterPhone;
	this->waiterTable=waiterTable;
	
	Waiters.push_back(*this);
}


