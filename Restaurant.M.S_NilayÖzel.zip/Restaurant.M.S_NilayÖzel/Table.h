#include <iostream>
#include <string>
#include <vector>
#include <array>

using namespace std;

//table-7
void TableInfo();
void tableOperation();
void AddTable();
void DeleteTable();
void EditTable();
void ShowTable();

int compareTableId(int id);  

void HomeScreen();

//  CLASS TABLE
class Table{
	
	public:
		
		int tableId;
		int tableBill;
	
	Table(int, int);	
		
	void TableInfo() {
		cout << "Table Id: "<<tableId<< endl;
		cout << "      Bill: "<<tableBill<< endl;
		cout<<"\n";
	}
	
};

vector<Table>Tables;

Table::Table(int tableId, int tableBill){
	
	this->tableId=tableId;
	this->tableBill=tableBill;
	
	Tables.push_back(*this);
}

