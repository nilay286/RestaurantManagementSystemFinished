#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <array>
#include "Chef.h"
#include "Customer.h"
#include "Servant.h"
#include "Table.h"
#include "Waiter.h"

using namespace std;

//customer-9
void CustomerInfo();
void customerOperation();
void AddCustomer();
void DeleteCustomer();
void EditCustomer();
void ShowCustomer();

int compareCustomerId(int id); 
int compareCustomerPhone(int phone); 
int compareCustomerTablenum(int table); 

//table-7
void TableInfo();
void tableOperation();
void AddTable();
void DeleteTable();
void EditTable();
void ShowTable();

int compareTableId(int id); 

//waiter-10
void WaiterInfo();
void waiterOperation();
void AddWaiter();
void DeleteWaiter();
void EditWaiter();
void ShowWaiter();

int compareWaiterId(int id); 
int compareWaiterPhone(int phone); 
int compareWaiterTable(int table);
int compareWaiterAge(int age); 
 
//servant-10
void ServantInfo();
void servantOperation();
void AddServant();
void DeleteServant();
void EditServant();
void ShowServant();

int compareServantId(int id); 
int compareServantPhone(int phone); 
int compareServantTable(int table);
int compareServantAge(int age);  


//chef-9
void ChefInfo();
void chefOperation();
void AddChef();
void DeleteChef();
void EditChef();
void ShowChef();

int compareChefId(int id);
int compareChefPhone(int phone); 
int compareChefAge(int age); 

//main-1
void HomeScreen();

// 46 fonksiyon,  15 k�s�t,  26 ko�ul [ 20(if-else) 6(switch-case) ]

//CUSTOMER 
int compareCustomerId(int id){
//Comparing entered and existing id	
	
	int array[]={};
	
	for(auto x : Customers){	
		for(int i=0 ; i<Customers.size(); i++){
			array[i]=x.customerId;
	
		if(id==array[i]){
			Customers.erase(Customers.end() - 1);
			return 0;
			}
		else{
			customerOperation();
			return 1;
			}
		}
	}
}

int compareCustomerPhone(int phone){
//Comparing entered and existing phone numbers
//Because everyone's phone numbers are different

	int array[]={};
	
	for(auto x : Customers){ 	
		for(int i=0 ; i<Customers.size(); i++){
			array[i]=x.customerPhone;
	
		if(phone==array[i]){
			Customers.erase(Customers.end() - 1);
			return 0;
			}
		else{
			customerOperation();
			return 1;
			}
		}
	}

}

int compareCustomerTablenum(int table){
//No one else can reserve a full table.
	
	int array[]={};
	
	for(auto x : Customers){ 	
		for(int i=0 ; i<Customers.size(); i++){
			array[i]=x.customerTablenum;
	
		if(table==array[i]){
			Customers.erase(Customers.end() - 1);
			return 0;
			}
		else{
			customerOperation();
			return 1;
			}
		}
	}

}

void AddCustomer() {

	int custId;
	string custName;
	int custPhone;
	string custAddress;
	int custTablenum;
	
	cout<<"\nNEW CUSTOMER INFORMATION"<<endl;
	cout << "Id: ";
	cin>>custId ;	
	cout << "Name:  ";
	cin >>custName;
	cout << "Phone: ";
	cin >>custPhone;
	cout << "Address: ";
	cin >>custAddress;
	cout << "Table number: ";
	cin >>custTablenum;
	
	Customer newCustomer(custId, custName, custPhone, custAddress, custTablenum);

	if(compareCustomerId(custId)==0){
		cout<<"Id: "<<custId<<endl;
		cout<<"Please check your id - Id is different for everyone !"<<endl;
 	}
	if(compareCustomerPhone(custPhone)==0){
		cout<<"Phone: "<<custPhone<<endl;
		cout<<"Please check your phone - Phone number must be different from someone else's !"<<endl;	
 	}
 	if(compareCustomerTablenum(custTablenum)==0){
		cout<<"Table number: "<<custTablenum<<endl;
		cout<<"Please check your table number - You can't select full table !"<<endl;	
 	}
 	
}

void DeleteCustomer(){
	int a;
	cout<<"Enter The Customer Queue You Want To Be Deleted"<<endl;
	cin>>a;
	Customers.erase(Customers.begin()+(a-1));
		
}

void EditCustomer(){
	int a;
	cout<<"Enter The Customer Queue You Want To Be Edited"<<endl;
	cin>>a;
	Customers.erase(Customers.begin()+(a-1));
	AddCustomer();		
	
}

void ShowCustomer(){
	
		cout<<"\nAll Customers "<<endl;
			for(auto x: Customers){
			x.CustomerInfo();
			} 
				
}


// TABLE
int compareTableId(int id){
//Comparing entered and existing id	

	int array[]={};
	
	for(auto x : Tables){	
		for(int i=0 ; i<Tables.size(); i++){
			array[i]=x.tableId;
	
		if(id==array[i]){
			Tables.erase(Tables.end() - 1);
			return 0;
			}
		else{
			return 1;
			}
		}
	}	
}

void AddTable() {

	int tblId;
	int tblBill;
	
	cout<<"\nNEW TABLE INFORMATION"<<endl;
	cout << "Id: ";
	cin>>tblId ;
	cout << "Table Bill: ";
	cin >>tblBill;

	if(compareTableId(tblId)==0){
		cout<<"Id: "<<tblId<<endl;
		cout<<"Please check your id !"<<endl;
 	}
	
}

void DeleteTable(){
	int a;
	cout<<"Enter The Table Queue You Want To Be Deleted"<<endl;
	cin>>a;
	Tables.erase(Tables.begin()+(a-1));
		
}

void EditTable(){
	int a;
	cout<<"Enter The Table Queue You Want To Be Edited"<<endl;
	cin>>a;
	Tables.erase(Tables.begin()+(a-1));
	AddTable();		
	
}

void ShowTable(){
		cout<<"\nAll Tables "<<endl;
			for(auto y: Tables){
			y.TableInfo();	
		}			
}


// WAITER
int compareWaiterId(int id){
//Comparing entered and existing id	

	int array[]={};
	
	for(auto x : Waiters){	
		for(int i=0 ; i<Waiters.size(); i++){
			array[i]=x.waiterId;
	
		if(id==array[i]){
			Waiters.erase(Waiters.end() - 1);
			return 0;
			}
		else{
			return 1;
			}
		}
	}	
}

int compareWaiterPhone(int phone){
//Comparing entered and existing phone numbers
//Because everyone's phone numbers are different

	int array[]={};
	
	for(auto x : Waiters){ 	
		for(int i=0 ; i<Waiters.size(); i++){
			array[i]=x.waiterPhone;
	
		if(phone==array[i]){
			Waiters.erase(Waiters.end() - 1);
			return 0;
			}
		else{
			return 1;
			}
		}
	}

}
	
int compareWaiterTable(int table){
//No one else can take care of the table with a waiter
	
	int array[]={};
	
	for(auto x : Waiters){ 	
		for(int i=0 ; i<Waiters.size(); i++){
			array[i]=x.waiterTable;
	
		if(table==array[i]){
			Waiters.erase(Waiters.end() - 1);
			return 0;
			}
		else{
			return 1;
			}
		}
	}
}

int compareWaiterAge(int age){
//Persons below or above a certain age cannot be employed

		if(age<18 || age>30){
			Waiters.erase(Waiters.end() - 1);	
			return 0;
			}
		else{
			return 1;
			}	
}

void AddWaiter() {

	int wtrId;
	string wtrName;
	int wtrAge;
	int wtrPhone;
	int wtrTable;

	cout<<"\nNEW WAITER INFORMATION"<<endl;
	cout << "Id: ";
	cin >>wtrId ;
	cout << "Name:  ";
	cin >>wtrName;
	cout << "Age:  ";
	cin >>wtrAge;
	cout << "Phone: ";
	cin >>wtrPhone;
	cout << "Table: ";
	cin >>wtrTable;
	
	Waiter newWaiter(wtrId, wtrName, wtrAge, wtrPhone, wtrTable);

	if(compareWaiterId(wtrId)==0){
		cout<<"Id: "<<wtrId<<endl;
		cout<<"Please check your id - Id is different for everyone !"<<endl;
 	}
	if(compareWaiterPhone(wtrPhone)==0){
		cout<<"Phone: "<<wtrPhone<<endl;
		cout<<"Please check your phone - Phone number must be different from someone else's !"<<endl;	
 	}
 	if(compareWaiterTable(wtrTable)==0){
		cout<<"Table number: "<<wtrTable<<endl;
		cout<<"Please check your table number - This table has a waiter !"<<endl;	
 	}
 	if(compareWaiterAge(wtrAge)==0){
		cout<<"Age: "<<wtrAge<<endl;
		cout<<"Please check your age - You must be between the ages of 18-30 to work !"<<endl;	
 	}
	
}

void DeleteWaiter(){
	int a;
	cout<<"Enter The Waiter Queue You Want To Be Deleted"<<endl;
	cin>>a;
	Waiters.erase(Waiters.begin()+(a-1));
	
}

void EditWaiter(){
	int a;
	cout<<"Enter The Waiter Queue You Want To Be Edited"<<endl;
	cin>>a;
	Waiters.erase(Waiters.begin()+(a-1));
	AddWaiter();		
	
}

void ShowWaiter(){
		cout<<"\nAll Waiters "<<endl;
			for(auto x: Waiters){
			x.WaiterInfo();
		}
}
	
	
//SERVANT
int compareServantId(int id){
//Comparing entered and existing id	

	int array[]={};
	
	for(auto x : Servants){	
		for(int i=0 ; i<Servants.size(); i++){
			array[i]=x.servantId;
	
		if(id==array[i]){
			Servants.erase(Servants.end() - 1);
			return 0;
			}
		else{
			return 1;
			}
		}
	}	
}

int compareServantPhone(int phone){
//Comparing entered and existing phone numbers
//Because everyone's phone numbers are different

	int array[]={};
	
	for(auto x : Servants){ 	
		for(int i=0 ; i<Servants.size(); i++){
			array[i]=x.servantPhone;
	
		if(phone==array[i]){
			Servants.erase(Servants.end() - 1);
			return 0;
			}
		else{
			return 1;
			}
		}
	}

}

int compareServantTable(int table){
//No one else can take care of the table with a servant
	
	int array[]={};
	
	for(auto x : Servants){ 	
		for(int i=0 ; i<Servants.size(); i++){
			array[i]=x.servantTable;
	
		if(table==array[i]){
			Servants.erase(Servants.end() - 1);	
			return 0;
			}
		else{
			return 1;
			}
		}
	}

}

int compareServantAge(int age){
//Persons below or above a certain age cannot be employed

		if(age<18 || age>40){
			Servants.erase(Servants.end() - 1);	
			return 0;
			}
		else{
			return 1;
			}	
}

void AddServant() {

	int srvId;
	string srvName;
	int srvAge;
	int srvPhone;
	int srvTable;

	cout<<"\nNEW SERVANT INFORMATION"<<endl;
	cout << "Id: ";
	cin >>srvId ;
	cout << "Name:  ";
	cin >>srvName;
	cout << "Age:  ";
	cin >>srvAge;
	cout << "Phone: ";
	cin >>srvPhone;
	cout << "Table: ";
	cin >>srvTable;
	
	Servant newServant(srvId, srvName, srvAge, srvPhone, srvTable);
	
	if(compareServantId(srvId)==0){
		cout<<"Id: "<<srvId<<endl;
		cout<<"Please check your id - Id is different for everyone !"<<endl;
 	}
	if(compareServantPhone(srvPhone)==0){
		cout<<"Phone: "<<srvPhone<<endl;
		cout<<"Please check your phone - Phone number must be different from someone else's !"<<endl;	
 	}
 	if(compareServantTable(srvTable)==0){
		cout<<"Table number: "<<srvTable<<endl;
		cout<<"Please check your table number - This table has a servant !"<<endl;	
 	}
	if(compareServantAge(srvAge)==0){
		cout<<"Age: "<<srvAge<<endl;
		cout<<"Please check your age - You must be between the ages of 18-40 to work !"<<endl;	
 	}	
}

void DeleteServant(){
	int a;
	cout<<"Enter The Servant Queue You Want To Be Deleted"<<endl;
	cin>>a;
	Servants.erase(Servants.begin()+(a-1));
	
}

void EditServant(){
	int a;
	cout<<"Enter The Servant Queue You Want To Be Edited"<<endl;
	cin>>a;
	Servants.erase(Servants.begin()+(a-1));
	AddServant();		
	
}

void ShowServant(){
		cout<<"\nAll Servants "<<endl;
			for(auto x: Servants){
			x.ServantInfo();
		}
}


// CHEF	
int compareChefId(int id){
//Comparing entered and existing id	

	int array[]={};
	
	for(auto x : Chefs){	
		for(int i=0 ; i<Chefs.size(); i++){
			array[i]=x.chefId;
	
		if(id==array[i]){		
			Chefs.erase(Chefs.end() - 1);
			return 0;
			}
		else{
			return 1;
			}
		}
	}	
}

int compareChefPhone(int phone){
//Comparing entered and existing phone numbers
//Because everyone's phone numbers are different

	int array[]={};
	
	for(auto x : Chefs){ 	
		for(int i=0 ; i<Chefs.size(); i++){
			array[i]=x.chefPhone;
	
		if(phone==array[i]){
			Chefs.erase(Chefs.end() - 1);
			return 0;
			}
		else{
			return 1;
			}
		}
	}

}

int compareChefAge(int age){
//Persons below or above a certain age cannot be employed

		if(age<25 || age>45){
			Chefs.erase(Chefs.end() - 1);	
			return 0;
			}
		else{
			return 1;
			}	
}

void AddChef(){

	int chfId;
	string chfName;
	int chfAge;
	int chfPhone;

	cout<<"\nNEW CHEF INFORMATION"<<endl;
	cout << "Id: ";
	cin >>chfId ;
	cout << "Name:  ";
	cin >>chfName;
	cout << "Age:  ";
	cin >>chfAge;
	cout << "Phone: ";
	cin >>chfPhone;


	Chef newChefs(chfId, chfName, chfAge, chfPhone);

	if(compareChefId(chfId)==0){
		cout<<"Id: "<<chfId<<endl;
		cout<<"Please check your id - Id is different for everyone !"<<endl;
 	}
	if(compareChefPhone(chfPhone)==0){
		cout<<"Phone: "<<chfPhone<<endl;
		cout<<"Please check your phone Phone number must be different from someone else's !"<<endl;	
 	}
 	if(compareChefAge(chfAge)==0){
		cout<<"Age: "<<chfAge<<endl;
		cout<<"Please check your age - You must be between the ages of 25-45 to work !"<<endl;	
 	}
}

void DeleteChef(){
	int a;
	cout<<"Enter The Chef Queue You Want To Be Deleted"<<endl;
	cin>>a;
	Chefs.erase(Chefs.begin()+(a-1));
	
}

void EditChef(){
	int a;
	cout<<"Enter The Chef Queue You Want To Be Edited"<<endl;
	cin>>a;
	Chefs.erase(Chefs.begin()+(a-1));
	AddChef();		
	
}

void ShowChef(){
		cout<<"\nAll Chefs "<<endl;
			for(auto x: Chefs){
			x.ChefInfo();
	}
}


void HomeScreen(){
	
	cout<<"\n- - - - - - - - - - RESTAURANT MANAGEMENT SYSTEM - - - - - - - - - - \n"<<endl;
	
	int a;
	
	cout<<"Choose one of this operations: "<<endl;
	
	cout<<"1 - Customer Operation"<<endl;
	cout<<"2 - Table Operation"<<endl;
	cout<<"3 - Waiter Operation"<<endl;
	cout<<"4 - Chef Operation"<<endl;
	cout<<"5 - Servant Operation"<<endl;

	cin>>a;

	switch(a){
		case 1:{
			customerOperation();
		}
			break;
		
		case 2:{
			tableOperation();
		}
			break;
				
		case 3:{
			waiterOperation();
		}
			break;
		
		case 4:{
			chefOperation();
		}
			break;
			
		case 5:{
			servantOperation();
		}
			break;			
	}
		
}


int main(){
	
	Customer customer1(767, "Nilay",53799955, "Pendik",1);
	Customer customer2(247, "Nihal",53966677, "Beykoz",2);
	
	Table table1(1, 275);
	Table table2(2, 435);
	
	Waiter waiter1(987, "Yusuf",18,53277788,4);
	Waiter waiter2(768, "Ayse",26,52433577,6);
	
	Chef chef1(757, "Ali",28,53244466);
	Chef chef2(256, "Asli",37,53877655);

	Servant servant1(865, "Zeynep", 34,53144899, 6);
	Servant servant2(963, "Ahmet", 23,530666771, 5);
		
	HomeScreen();
	
	return 0;
}


//OPERATIONS
void customerOperation(){
	
	int x;
	int y=0;
	
while(y!=-1){
	
	cout<<"\nCustomer Operation"<<endl;
	cout<<"1. Add Customer"<<endl;
	cout<<"2. Delete Customer"<<endl;
	cout<<"3. Edit Customer"<<endl;
	cout<<"4. Show Customer's Information"<<endl;
	cout<<"5. Exit"<<endl;
	cin>>x;

	switch(x){
		
		case 1:{		
			AddCustomer();
		//	cout<<"That Customer is added."<<endl;
			cout <<"\nAll Customers In Restaurant is: "<<Customers.size() << endl;			
			break;
		}
			
		case 2:{			
			DeleteCustomer();
			cout<<"That Customer is deleted."<<endl;
			cout <<"\nAll Customers In Restaurant is: "<<Customers.size() << endl;
			break;
		}
		
		case 3:			
			EditCustomer();
			
		case 4:			
			ShowCustomer();
			
		case 5:
			HomeScreen();
		}
	}
}			

void tableOperation(){
	
	int x;
	int y=0;
	
while(y!=-1){
	
	cout<<"\nTable Operation"<<endl;
	cout<<"1. Add Table"<<endl;
	cout<<"2. Delete Table"<<endl;
	cout<<"3. Edit Table"<<endl;
	cout<<"4. Show Table's Information"<<endl;
	cout<<"5. Exit"<<endl;
	cin>>x;

	switch(x){
		
		case 1:{			
			AddTable();
		//	cout<<"That Table is added."<<endl;
			cout <<"\nNumber Of Tables With Reservation is: "<<Tables.size() << endl;			
		break;
		}
		
		case 2:
			DeleteTable();
			cout<<"That Table is deleted."<<endl;
			cout <<"\nAll Tables In Restaurant is: "<<Tables.size() << endl;
			break;

		case 3:	
			EditTable();
				
		case 4:			
			ShowTable();
			
		case 5:
			HomeScreen();
		}
	}
	
}

void waiterOperation(){
	
	int x;
	int y=0;
	
	while(y!=-1){
			
	cout<<"\nWaiter Operation"<<endl;																											
	cout<<"1. Add Waiter"<<endl;
	cout<<"2. Delete Waiter"<<endl;
	cout<<"3. Edit Waiter"<<endl;
	cout<<"4. Show Waiter's Information"<<endl;
	cout<<"5. Exit"<<endl;
	cin>>x;
	
	switch(x){
		
		case 1:	
			AddWaiter();
		//	cout<<"That Waiter is added."<<endl;
			cout <<"\nAll Waiters In Restaurant is: "<<Waiters.size() << endl;
			break;
	
		case 2:
			DeleteWaiter();
			cout<<"That Waiter is deleted."<<endl;
			cout <<"\nAll Waiters In Restaurant is: "<<Waiters.size() << endl;
			break;

		case 3:	
				EditWaiter();
						
		case 4:	
				ShowWaiter();
				
		case 5:			
				HomeScreen();
					
		}
	}
}

void chefOperation(){

	int x;
	int y=0;
	
while(y!=-1){
	
	cout<<"\nChef Operation"<<endl;
	cout<<"1. Add Chef"<<endl;
	cout<<"2. Delete Chef"<<endl;
	cout<<"3. Edit Chef"<<endl;
	cout<<"4. Show Chef's Information"<<endl;
	cout<<"5. Exit"<<endl;
	cin>>x;
	
	
	switch(x){
		case 1:
			AddChef();
	//		cout<<"That Chef is added."<<endl;
			cout <<"\nAll Chefs In Restaurant is: "<<Chefs.size() << endl;
			break;
			
		case 2:	
			DeleteChef();
			cout<<"That Chef is deleted."<<endl;
			cout <<"\nAll Chefs In Restaurant is: "<<Chefs.size() << endl;
			break;
			
		case 3:		
				EditChef();	
						
		case 4:		
				ShowChef();
			
		case 5:
				HomeScreen();				
		}
	}
}

void servantOperation(){
	
	int x;
	int y=0;
	
	while(y!=-1){
			
	cout<<"\nServant Operation"<<endl;																											
	cout<<"1. Add Servant"<<endl;
	cout<<"2. Delete Servant"<<endl;
	cout<<"3. Edit Servant"<<endl;
	cout<<"4. Show Servant's Information"<<endl;
	cout<<"5. Exit"<<endl;
	cin>>x;
	
	switch(x){
		
		case 1:	
			AddServant();
		//	cout<<"That Servant is added."<<endl;
			cout <<"\nAll Servant In Restaurant is: "<<Servants.size() << endl;
			break;
	
		case 2:
			DeleteServant();
			cout<<"That Servant is deleted."<<endl;
			cout <<"\nAll Servant In Restaurant is: "<<Servants.size() << endl;
			break;

		case 3:	
				EditServant();
						
		case 4:	
				ShowServant();
				
		case 5:			
				HomeScreen();
					
		}
	}
}

